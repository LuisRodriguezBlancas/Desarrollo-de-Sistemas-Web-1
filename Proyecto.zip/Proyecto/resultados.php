<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>¡Resultados de datos!</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="dive2">
    <h1>¡Resultados!</h1>
    <center>
        <img src="img/imagen 1.jpeg" alt="Batman">

        <h2>¡Bien Hecho!</h2>

<?php
$name = $_POST['Name'];
$age = $_POST['Age'];
$city = $_POST['City'];
$birthday = $_POST['Birthday'];
$hobby = $_POST['Hobby'];

echo '<p><b>Nombre:</b> '.$name.'</p>';
echo '<p><b>Edad:</b> '.$age.'</p>';
echo '<p><b>Ciudad:</b> '.$city.'</p>';
echo '<p><b>Fecha de nacimiento:</b> '.$birthday.'</p>';
echo '<p><b>Pasatiempo:</b> '.$hobby.'</p>';

?>

<div id="popUpOverlay"></div>
<div id="popUpBox">
<div id="box">
    <i class="fas fa-question-circle fa-5x"></i>
    <h1>¿Volver a ingresar datos?</h1>
    <div id="CloseModal"></div>
</div>
</div>
<button onclick="Alert.render('Tu te miras muy bien hoy.')" class="btn">¡Volver a ingresar!</button>
    </center>
   
    <script src="js/app.js"></script>
   </div>
    
</body>
</html>